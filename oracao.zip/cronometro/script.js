var div = document.getElementById('log');
var textos = ['Eu sou filho de Deus. Deus mora dentro de mim. Eu sou uma manifestação de Deus e tenho o direito divino de criar a vida que que desejo. Eu sigo com a confiança sabendo que eu, como filho de Deus, tenho você do meu lado e que o senhor morando dentro de mim, não há força que possa estar contra mim. eu declaro agora, porque o Deus dentro de mim que é uma parte minha, que eu tenho o dinheiro que desejo, eu tenho a casa perfeita para mim, tudo me é concedido pelos caminho da graça, na paz e no amor, porque eu mereço. Eu agraceço por saber disso tudo, eu agradeço por tanto amor que recebo. Obrigado porque eu sei que tudo de bom está à caminho sempre. Obrigado Deus por me abençoar com tudo que tenho na vida. Eu sei que sou uma manifestação do Deus que mora dentro de mim, eu sei que eu crio a vida que desejo. Eu sei que posso ter tudo que eu quero desde que acredito e tenha determinação, fé  e tome medidas para receber das mãos de Deus. Eu me vejo tendo o emprego perfeito com o slario perfeito, de uma maneira perfeita. Eu me vejo tendo um lar perfeito, num bairro agradavel, com vizinhos educados. Eu me vejo com toda a minha conta bancaria transbordando de dinheiro, permitindo comprar, poupar, doar a quem precisa. Eu me vejo tendo saúde, um corpo que funciona bem e me permite experimentar as mais incriveis experiências neste planeta. Eu me vejo tendo relacionamentos saudaveis com minha família, meus amigos. Eu me conecto com apenas com pessoas de elevada vibração, que buscam o mesmo propósito. Eu sou feliz porque sei a verdade. Eu sou feliz porque sou abundantemente suprido pelo amor de Deus que habita em mim. Amém, que assim seja sempre!  Hoje está um lindo dia!', 'Ontem também... lindo lindo!', 'Amanha ouvi dizer que vai chover... vamos ver...', 'Boa noite, até amanhã.', 'Bons sonhos...zzZZZzzzz......'];

function escrever(str, done) {
    var char = str.split('').reverse();
    var typer = setInterval(function() {
        if (!char.length) {
            clearInterval(typer);
            return setTimeout(done, 2500); // só para esperar um bocadinho
        }
        var next = char.pop();
        div.innerHTML += next;
    }, 100);
}

function rodape(conteudos, el) {
    var atual = -1;
	function prox(){
		if (atual < conteudos.length - 1) atual++;
		else atual = 0;
		var str = conteudos[atual];
		escrever(str, function(){
			div.innerHTML = '';
			prox();
		});
	}
	prox();
}
rodape(textos);